//
//  MenuItems.swift
//  NRK_PARKING
//
//  Created by MacStudent on 2018-03-05.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class MenuItems {
    let names:[String] = [
        "ADD PARKING",
        "LOCATION",
        "REPORT",
        "MANUAL",
        "SUPPORT",
        "PROFILE",
        "LOG OUT"
    ]
}
