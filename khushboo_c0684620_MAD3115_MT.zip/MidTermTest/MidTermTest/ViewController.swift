//
//  ViewController.swift
//  MidTermTest
//
//  Created by MacStudent on 2018-02-28.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var switchRememberMe: UISwitch!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        getData()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    @IBAction func btnLoginClick(_ sender: UIButton) {
        
        let Username = txtUsername.text
        let Password = txtPassword.text
        
        if (Username == "test" && Password == "test"){
            
            let registerSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            
            if switchRememberMe.isOn{
                saveData();
            }
            
            let registerVC = registerSB.instantiateViewController(withIdentifier: "InventoryScreen")
            navigationController?.pushViewController(registerVC, animated: true)
            
        }else{
            
            let infoAlert = UIAlertController(title: "Login Failed", message: "Wrong credentials", preferredStyle: .alert)
            
            infoAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            
            self.present(infoAlert, animated: true, completion: nil)
        }
        
        
    }
    
    
    func saveData(){
        UserDefaults.standard.set(self.txtUsername.text,forKey: "userName")
        UserDefaults.standard.set(self.txtPassword.text,forKey:"password" )
    }
    
    func getData(){
        if let username = UserDefaults.standard.value(forKey: "userName"){
            self.txtUsername.text = username as? String
        }
        
        if let password = UserDefaults.standard.value(forKey: "password")  {
            self.txtPassword.text = password as? String
        }
    }
    
    

}

