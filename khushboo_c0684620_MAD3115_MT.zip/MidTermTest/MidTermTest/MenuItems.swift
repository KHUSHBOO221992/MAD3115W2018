//
//  MenuItems.swift
//  MidTermTest
//
//  Created by MacStudent on 2018-02-28.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class MenuItems {
    var buyers:[String] = []
    var productQuantities:[String] = []
    var productNames:[String] = []
    var productNumbers:[String] = []
    var productRemarks:[String] = []
}

/*
class MenuItems {
    var buyers:[String] = [
        "Caio", "JK", "Pulkit"
    ]
    var productQuantities:[Int] = [
        3,6,2
    ]
    var productNames:[String] = [
        "Desk", "Chair", "Table"]
}*/

