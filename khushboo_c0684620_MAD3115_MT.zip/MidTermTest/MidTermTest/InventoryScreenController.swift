//
//  InventoryScreenController.swift
//  MidTermTest
//
//  Created by MacStudent on 2018-02-28.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class InventoryScreenController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
        var menuList: MenuItems!
    
    
    @IBOutlet weak var moodsSEgment: UISegmentedControl!
    @IBOutlet weak var imgProduct: UIImageView!
    @IBOutlet weak var stepperQuantity: UIStepper!
    @IBOutlet weak var lblQuantity: UILabel!
    @IBOutlet weak var txtRemarks: UITextField!
    
    @IBAction func stepperQuantityAction(_ sender: UIStepper) {
                lblQuantity.text = String(stepperQuantity.value)
    }
    @IBAction func btnSaveDetailsClick(_ sender: UIButton) {
        let infoAlert = UIAlertController(title: "Successful", message: "Product added", preferredStyle: .alert)
        
        infoAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        
        
        var productNameIndex = self.pickerProductName.selectedRow(inComponent: 0)
        var productNameSelected = self.productNameList[productNameIndex]
        
        var productNumberIndex = self.pickerProductName.selectedRow(inComponent: 0)
        var productNumberSelected = self.productNumberList[productNumberIndex]
        
        var productQuantity = lblQuantity.text!
        var remarks = txtRemarks.text!
        
        
        var newPurchase = Purchase(pName: "test", pProductName: productNameSelected, pProductQuantity: productQuantity, pProductNumber: productNumberSelected, pRemarks: remarks);
        
        Purchase.addPurchase(newPurchase: newPurchase)
        
        self.present(infoAlert, animated: true, completion: nil)
    }
    
    @IBAction func btnListProductsClick(_ sender: UIButton) {
        let lstProductSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let lstProductScreen = lstProductSB.instantiateViewController(withIdentifier: "ListProductsScreen")
        
        navigationController?.pushViewController(lstProductScreen, animated: true)
        
        
    }
    
    //picker data source
        var productNumberList: [String] = ["010181","819201", "829191"]
        var productNameList: [String] = ["Desk","Table", "Window"]
        var selectedProductNumberIndex: Int = 0
        var selectedProductNameIndex: Int = 0
    
    
    var moodImages: [UIImage] = [
        UIImage(named: "Chair.JPG")!,
        UIImage(named: "Table.JPG")!,
        UIImage(named: "Windows.jpg")!
    ]
    
    @IBAction func segmentedChanged(_ sender: UISegmentedControl) {
        print("selected : \(moodsSEgment.selectedSegmentIndex)")
        
        imgProduct.image = moodImages[moodsSEgment.selectedSegmentIndex]
        
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if pickerView.restorationIdentifier == "pickerProductNumber"{
            return self.productNumberList.count
            
        }else{
            return self.productNameList.count
        }

    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if pickerView.restorationIdentifier == "pickerProductNumber"{
        return self.productNumberList[row]
        }else{
        return self.productNameList[row]
        }
        
    }
    

    @IBOutlet weak var pickerProductNumber: UIPickerView!
    
    @IBOutlet weak var pickerProductName: UIPickerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        //add data in picker
        self.pickerProductName.delegate = self
        self.pickerProductName.dataSource = self
        self.pickerProductNumber.delegate = self
        self.pickerProductNumber.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
