//
//  Purchase.swift
//  MidTermTest
//
//  Created by MacStudent on 2018-02-28.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Purchase{
    var Name: String!
    var ProductName: String!
    var ProductQuantity: String!
    var ProductNumber: String!
    var Remarks: String!
    private static var purchaseList = [String: Purchase]()
    
    init(){
        self.Name = ""
        self.ProductName = ""
        self.ProductQuantity = "1"
        self.ProductNumber = "101010"
        self.Remarks = ""
    }
    
    init(pName: String, pProductName: String, pProductQuantity: String, pProductNumber: String, pRemarks: String){
        self.Name = pName
        self.ProductName = pProductName
        self.ProductQuantity = pProductQuantity
        self.ProductNumber = pProductNumber
        self.Remarks = pRemarks
    }
    
    static func addPurchase(newPurchase: Purchase) -> Bool{
        var newKey = String(purchaseList.count + 1)
        self.purchaseList[newKey] = newPurchase
        return true;
    }
    
    static func getAllPurchases() -> [String:Purchase] {
        return purchaseList
    }
}
