//
//  MomentsCell.swift
//  KHUSHBOO_CO684620_MAD3115_FT
//
//  Created by MacStudent on 2018-03-12.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class MomentsCell: UICollectionViewCell {
    
    @IBOutlet var lblMomentTitle: UILabel!
    @IBOutlet var imgMoment: UIImageView!
    
}
